<?php

header("Content-Type: application/json; charset=UTF-8");
echo "\xEF\xBB\xBF"; // FIX UTF-8 BOM
$host = "sql305.infinityfree.com";

$username = "if0_40606621";

$password = "0564551032";

$database = "if0_40606621_keysystem";

$conn = mysqli_connect($host, $username, $password, $database);

mysqli_set_charset($conn, "utf8");

if (!$conn) {

    die(json_encode(["status" => "error", "message" => "Không thể kết nối database: " . mysqli_connect_error()]));

}

$key = isset($_GET['key']) ? $_GET['key'] : '';

if (empty($key)) {

    die(json_encode(["status" => "error", "message" => "Bạn chưa nhập key"]));

}

$sql = "SELECT * FROM `keys` WHERE thekey='$key' LIMIT 1";

$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {

    echo json_encode(["status" => "success", "message" => "KEY ĐÚNG 🎉"]);

} else {

    echo json_encode(["status" => "error", "message" => "KEY SAI RỒI 💥"]);

}

?>