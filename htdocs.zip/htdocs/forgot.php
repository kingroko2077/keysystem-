<?php

$host = "sql305.infinityfree.com";

$username = "if0_40606621";

$password = "0564551032";

$database = "if0_40606621_keysystem";

$conn = mysqli_connect($host, $username, $password, $database);

mysqli_set_charset($conn, "utf8");

if (!$conn) {

    die("Không kết nối được database");

}

?>

<!DOCTYPE html>

<html lang="vi">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Quên mật khẩu</title>

<style>

    body {

        margin: 0;

        padding: 0;

        font-family: Arial, sans-serif;

        background: linear-gradient(135deg, #6a11cb, #2575fc);

        height: 100vh;

        display: flex;

        justify-content: center;

        align-items: center;

    }

    .form-container {

        width: 550px;              /* 🔥 TO Y CHANG LOGIN */

        background: #fff;

        padding: 40px;

        border-radius: 15px;

        box-shadow: 0 10px 30px rgba(0,0,0,0.15);

        text-align: center;

        animation: fadeIn 0.4s ease;

    }

    @keyframes fadeIn {

        from { opacity: 0; transform: translateY(20px); }

        to { opacity: 1; transform: translateY(0); }

    }

    h2 {

        margin-bottom: 10px;

        font-size: 28px;

        font-weight: bold;

    }

    p {

        color: #555;

        margin-bottom: 25px;

    }

    input {

        width: 100%;

        padding: 12px;

        margin-bottom: 18px;

        border-radius: 8px;

        border: 1px solid #ccc;

        font-size: 16px;

    }

    .btn {

        width: 100%;

        padding: 14px;

        background: #2575fc;

        color: white;

        border: none;

        border-radius: 8px;

        font-size: 18px;

        cursor: pointer;

        margin-bottom: 15px;

    }

    .btn:hover {

        background: #1464e0;

    }

    a {

        color: #2575fc;

        text-decoration: none;

        font-size: 15px;

    }

    a:hover {

        text-decoration: underline;

    }

</style>

</head>

<body>

<div class="form-container">

    <h2>Quên mật khẩu</h2>

    <p>Vui lòng nhập email đã đăng ký</p>

    <form action="reset.php" method="POST">

        <input type="email" name="email" placeholder="Nhập email đăng ký" required>

        <button class="btn" type="submit">Lấy lại mật khẩu</button>

    </form>

    <a href="login.php">← Quay lại đăng nhập</a>

</div>

</body>

</html>