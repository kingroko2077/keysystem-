<?php

error_reporting(E_ALL);

ini_set('display_errors', 1);

// ================== CONFIG DATABASE ==================

$host = "sql305.infinityfree.com";

$username = "if0_40606621";

$password = "0564551032";

$database = "if0_40606621_keysystem";

$conn = mysqli_connect($host, $username, $password, $database);

mysqli_set_charset($conn, "utf8");

if (!$conn) {

    die("<h2>Lỗi kết nối database.</h2>");

}

// ================== LẤY ID ==================

if (!isset($_GET['id'])) {

    die("<h2>Thiếu ID key.</h2>");

}

$id = intval($_GET['id']);

// ================== LẤY KEY TỪ DB ==================

$stmt = mysqli_prepare($conn, "SELECT thekey, expires FROM `keys` WHERE id = ?");

mysqli_stmt_bind_param($stmt, "i", $id);

mysqli_stmt_execute($stmt);

mysqli_stmt_store_result($stmt);

if (mysqli_stmt_num_rows($stmt) == 0) {

    mysqli_stmt_close($stmt);

    die("<h2>Key không tồn tại.</h2>");

}

mysqli_stmt_bind_result($stmt, $thekey, $expires);

mysqli_stmt_fetch($stmt);

mysqli_stmt_close($stmt);

// ================== KIỂM TRA HẾT HẠN ==================

$now = time();

$timeLeft = $expires - $now;

if ($timeLeft <= 0) {

    die("<h2>Key đã hết hạn.</h2>");

}

// ================== HTML HIỂN THỊ KEY ==================

?>

<!doctype html>

<html lang="vi">

<head>

<meta charset="utf-8">

<title>SHOW KEY</title>

<meta name="viewport" content="width=device-width, initial-scale=1">

<style>

    body {

        background: #000;

        margin: 0;

        font-family: Arial;

        color: #fff;

        display: flex;

        justify-content: center;

        align-items: center;

        height: 100vh;

        background-image: url('background.jpg');

        background-size: cover;

        background-position: center;

    }

    .box {

        background: rgba(0,0,0,0.7);

        padding: 30px;

        border-radius: 16px;

        text-align: center;

        width: 90%;

        max-width: 420px;

        box-shadow: 0 0 20px rgba(0,0,0,0.6);

    }

    .key {

        font-size: 28px;

        margin: 20px 0;

        word-break: break-all;

        background: #111;

        padding: 12px;

        border-radius: 12px;

        border: 1px solid #00c3ff;

    }

    button {

        padding: 12px 18px;

        font-size: 18px;

        border: none;

        border-radius: 10px;

        background: #00c3ff;

        cursor: pointer;

        font-weight: bold;

    }

    button:active {

        transform: scale(0.97);

    }

</style>

</head>

<body>

<div class="box">

    <h2>🔑 KEY CỦA BẠN</h2>

    <div class="key" id="keyText"><?= htmlspecialchars($thekey) ?></div>

    <button onclick="copyKey()">COPY KEY</button>

    <p style="margin-top:15px;color:#ccc">

        Hạn sử dụng còn: <?= gmdate("H:i:s", $timeLeft) ?>

    </p>

</div>

<script>

function copyKey() {

    const key = document.getElementById("keyText").innerText;

    navigator.clipboard.writeText(key).then(()=>{

        alert("Đã copy key!");

    });

}

</script>

</body>

</html>