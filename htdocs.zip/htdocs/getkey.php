<?php

error_reporting(E_ALL);

ini_set('display_errors', 1);

// ================== CONFIG DATABASE ==================

$host = "sql305.infinityfree.com";

$username = "if0_40606621";

$password = "0564551032";

$database = "if0_40606621_keysystem";

$conn = mysqli_connect($host, $username, $password, $database);

mysqli_set_charset($conn, "utf8");

if (!$conn) {

    die(json_encode([

        "status" => "error",

        "message" => "Không thể kết nối database"

    ]));

}

// ================== HÀM TẠO KEY NGẪU NHIÊN ==================

function randomKey($length = 32) {

    return bin2hex(random_bytes($length / 2));

}

// ================== TẠO KEY ==================

$thekey = randomKey(32);

$expires = time() + 3600; // 1 giờ (tùy m đổi)

// ================== LƯU KEY VÀO DB ==================

$stmt = mysqli_prepare($conn, "INSERT INTO `keys` (thekey, expires) VALUES (?, ?)");

mysqli_stmt_bind_param($stmt, "si", $thekey, $expires);

if (!mysqli_stmt_execute($stmt)) {

    die(json_encode([

        "status" => "error",

        "message" => "Không thể lưu key"

    ]));

}

$id = mysqli_insert_id($conn);

mysqli_stmt_close($stmt);

// ================== TRẢ VỀ LINK SHOW KEY ==================

echo json_encode([

    "status" => "success",

    "id" => $id,

    "key" => $thekey,

    "show_url" => "https://".$_SERVER['HTTP_HOST']."/showkey.php?id=".$id

], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

?>