<?php

session_start();

// ================== CONFIG DATABASE ==================

$host = "sql305.infinityfree.com";

$username = "if0_40606621";

$password = "0564551032";

$database = "if0_40606621_keysystem";

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {

    die("Lỗi kết nối database!");

}

$conn->set_charset("utf8");

$response = ["success" => false, "message" => ""];

// ================== REGISTER HANDLE ==================

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $user = trim($_POST["username"] ?? "");

    $pass = trim($_POST["password"] ?? "");

    $confirm = trim($_POST["confirm"] ?? "");

    if ($user === "" || $pass === "" || $confirm === "") {

        $response["message"] = "Vui lòng điền đầy đủ thông tin!";

    } elseif ($pass !== $confirm) {

        $response["message"] = "Mật khẩu xác nhận không khớp!";

    } else {

        // Kiểm tra username có tồn tại chưa

        $check = $conn->prepare("SELECT id FROM users WHERE username=?");

        $check->bind_param("s", $user);

        $check->execute();

        $result = $check->get_result();

        if ($result->num_rows > 0) {

            $response["message"] = "Tên đăng nhập đã tồn tại!";

        } else {

            // Hash password

            $hash = password_hash($pass, PASSWORD_BCRYPT);

            // Insert user

            $stmt = $conn->prepare("INSERT INTO users (username, password, role) VALUES (?, ?, 'user')");

            $stmt->bind_param("s", $user);

            $stmt->bind_param("s", $hash);

            if ($stmt->execute()) {

                $response["success"] = true;

                $response["message"] = "Đăng ký thành công!";

            } else {

                $response["message"] = "Lỗi server!";

            }

            $stmt->close();

        }

        $check->close();

    }

}

?>

<!DOCTYPE html>

<html lang="vi">

<head>

<meta charset="UTF-8">

<title>Đăng Ký</title>

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<style>

    *{margin:0;padding:0;box-sizing:border-box;font-family:Arial}

    body{

        height:100vh;

        display:flex;

        justify-content:center;

        align-items:center;

        background:linear-gradient(135deg,#6C2BD9,#4A148C);

    }

    .register-box{

        background:white;

        width:90%;

        max-width:360px;

        padding:35px 30px;

        border-radius:10px;

        box-shadow:0 5px 25px rgba(0,0,0,0.2);

        text-align:center;

    }

    h2{

        font-size:23px;

        color:#2d2d2d;

        margin-bottom:20px;

    }

    .form-group{margin-bottom:20px;text-align:left}

    .form-group label{font-size:14px;color:#555;margin-bottom:5px;display:block}

    

    .form-group input{

        width:100%;

        padding:12px;

        border:1px solid #ddd;

        border-radius:6px;

        font-size:14px;

    }

    .form-group input:focus{

        border-color:#6C2BD9;

        outline:none;

    }

    .btn{

        width:100%;

        background:#007BFF;

        border:none;

        padding:13px;

        color:white;

        border-radius:6px;

        font-size:16px;

        cursor:pointer;

        margin-top:10px;

    }

    .btn:hover{background:#0056D2}

    .login-link{

        margin-top:18px;

        font-size:14px;

        color:#444;

    }

    .login-link a{color:#007BFF;font-weight:600;text-decoration:none}

    .alert{

        padding:12px;

        margin-bottom:15px;

        border-radius:6px;

        font-size:14px;

        text-align:left;

    }

    .alert-success{background:#D4EDDA;color:#155724}

    .alert-error{background:#F8D7DA;color:#721C24}

</style>

</head>

<body>

<div class="register-box">

    <h2>Đăng Ký</h2>

    <?php if ($_SERVER["REQUEST_METHOD"] === "POST"): ?>

        <div class="alert <?php echo $response["success"] ? "alert-success":"alert-error"; ?>">

            <?php echo $response["message"]; ?>

        </div>

    <?php endif; ?>

    <form method="POST">

        <div class="form-group">

            <label>Tên đăng nhập</label>

            <input type="text" name="username" placeholder="Nhập username" required>

        </div>

        <div class="form-group">

            <label>Mật khẩu</label>

            <input type="password" name="password" placeholder="Nhập mật khẩu" required>

        </div>

        <div class="form-group">

            <label>Xác nhận mật khẩu</label>

            <input type="password" name="confirm" placeholder="Nhập lại mật khẩu" required>

        </div>

        <button class="btn" type="submit">Đăng Ký</button>

    </form>

    <div class="login-link">

        Đã có tài khoản? <a href="login.php">Đăng nhập</a>

    </div>

</div>

</body>

</html>