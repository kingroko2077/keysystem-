<style>

/* NÚT 3 GẠCH */

#openMenu {

    position: fixed;

    top: 15px;

    left: 15px;

    background: rgba(255,255,255,0.85);

    padding: 10px 14px;

    border-radius: 10px;

    cursor: pointer;

    z-index: 9999;

    font-size: 22px;

    backdrop-filter: blur(5px);

    border: none;

}

/* MENU BÊN TRÁI */

#sideMenu {

    position: fixed;

    top: 0;

    left: -250px;

    width: 250px;

    height: 100vh;

    background: rgba(0,0,0,0.85);

    color: white;

    padding: 25px;

    transition: 0.3s;

    z-index: 9998;

    backdrop-filter: blur(10px);

}

#sideMenu a {

    display: block;

    color: white;

    text-decoration: none;

    padding: 10px 0;

    font-size: 18px;

}

#sideMenu a:hover {

    color: #00c3ff;

}

/* NÚT ĐÓNG */

#closeMenu {

    font-size: 22px;

    cursor: pointer;

    color: #fff;

    margin-bottom: 20px;

    display: inline-block;

}

</style>

<button id="openMenu">☰</button>

<div id="sideMenu">

    <span id="closeMenu">✖ Đóng</span>

    <a href="index.php">🏠 Trang chủ</a>

    <a href="login.php">🔐 Đăng nhập</a>

    <a href="register.php">📝 Đăng ký</a>

    <a href="https://youtube.com/@kirbynamsicv?si=fudTtv6pETRZONdq">▶ YouTube</a>

    <a href="https://www.facebook.com/share/1EjTsuACnw/">📘 Facebook</a>

</div>

<script>

let menu = document.getElementById("sideMenu");

let openBtn = document.getElementById("openMenu");

let closeBtn = document.getElementById("closeMenu");

openBtn.onclick = () => {

    menu.style.left = "0";

};

closeBtn.onclick = () => {

    menu.style.left = "-250px";

};

</script>