<?php

session_start();

// Nếu chưa login thì đuổi về trang login

if (!isset($_SESSION['admin'])) {

    header("Location: admin_login.php");

    exit;

}

// ================== DATABASE ===================

$host = "sql305.infinityfree.com";

$username = "if0_40606621";

$password = "MẬT_KHẨU_VPANEL";

$database = "if0_40606621_keysystem";

$conn = mysqli_connect($host, $username, $password, $database);

mysqli_set_charset($conn, "utf8");

// ================== XÓA KEY ====================

if (isset($_GET['delete'])) {

    $id = intval($_GET['delete']);

    mysqli_query($conn, "DELETE FROM `keys` WHERE id = $id");

    header("Location: dashboard.php");

    exit;

}

// ================== RESET KEY ==================

if (isset($_GET['reset'])) {

    $id = intval($_GET['reset']);

    mysqli_query($conn, "UPDATE `keys` SET used = 0 WHERE id = $id");

    header("Location: dashboard.php");

    exit;

}

// ================== THÊM KEY ====================

if (isset($_POST['addkey'])) {

    $key = $_POST['key'];

    $expires = time() + 86400; // 24 giờ

    mysqli_query($conn, "INSERT INTO `keys` (`thekey`,`expires`) VALUES ('$key','$expires')");

    header("Location: dashboard.php");

    exit;

}

// ================== LẤY LIST KEY ================

$list = mysqli_query($conn, "SELECT * FROM `keys` ORDER BY id DESC");

?>

<!DOCTYPE html>

<html>

<head>

<meta charset="utf-8">

<title>Dashboard Admin</title>

<style>

    body {

        background: #111;

        color: white;

        font-family: Arial;

    }

    .container {

        width: 90%;

        margin: auto;

        margin-top: 30px;

    }

    h2 {

        text-align: center;

        font-size: 30px;

    }

    table {

        width: 100%;

        background: #222;

        border-collapse: collapse;

        margin-top: 20px;

        border-radius: 10px;

        overflow: hidden;

    }

    table th, table td {

        padding: 12px;

        border-bottom: 1px solid #333;

        text-align: center;

    }

    table th {

        background: #00c3ff;

        color: black;

    }

    .btn {

        padding: 6px 12px;

        background: #00c3ff;

        color: black;

        border-radius: 7px;

        text-decoration: none;

        font-weight: bold;

    }

    .btn-red {

        background: red;

        color: white;

    }

    .add-box {

        margin-top: 25px;

        padding: 20px;

        background: #222;

        border-radius: 10px;

    }

    input {

        width: 100%;

        padding: 10px;

        border-radius: 8px;

        margin-top: 10px;

        border: none;

    }

    button {

        margin-top: 10px;

        width: 100%;

        padding: 10px;

        background: #00c3ff;

        border-radius: 8px;

        border: none;

        font-size: 17px;

        font-weight: bold;

    }

</style>

</head>

<body>

<div class="container">

<h2>ADMIN DASHBOARD</h2>

<div class="add-box">

    <h3>Thêm key thủ công</h3>

    <form method="POST">

        <input type="text" name="key" placeholder="Nhập key cần thêm">

        <button name="addkey">Thêm key</button>

    </form>

</div>

<table>

    <tr>

        <th>ID</th>

        <th>KEY</th>

        <th>Hết hạn</th>

        <th>Đã dùng?</th>

        <th>Hành động</th>

    </tr>

<?php

while ($row = mysqli_fetch_assoc($list)) {

    echo "<tr>";

    echo "<td>".$row['id']."</td>";

    echo "<td>".$row['thekey']."</td>";

    echo "<td>".date("d/m/Y H:i", $row['expires'])."</td>";

    echo "<td>".($row['used'] ? "✔" : "✖")."</td>";

    echo "<td>

        <a class='btn' href='dashboard.php?reset=".$row['id']."'>Reset</a> 

        <a class='btn btn-red' href='dashboard.php?delete=".$row['id']."'>Xóa</a>

    </td>";

    echo "</tr>";

}

?>

</table>

</div>

</body>

</html>