<?php

session_start();

$admin_password = "123456"; // Mật khẩu admin

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $pass = $_POST['password'] ?? '';

    if ($pass === $admin_password) {

        $_SESSION['admin'] = true;

        header("Location: dashboard.php");

        exit;

    } else {

        $error = "Sai mật khẩu!";

    }

}

?>

<!DOCTYPE html>

<html lang="vi">

<head>

    <meta charset="UTF-8">

    <title>Admin Login</title>

    <style>

        body {

            background: #151515;

            color: white;

            font-family: Arial;

            display: flex;

            justify-content: center;

            align-items: center;

            height: 100vh;

        }

        .box {

            background: #222;

            padding: 25px;

            border-radius: 10px;

            width: 320px;

            text-align: center;

        }

        input {

            width: 100%;

            padding: 10px;

            margin-top: 12px;

            border-radius: 6px;

            border: none;

        }

        button {

            width: 100%;

            padding: 10px;

            margin-top: 15px;

            background: #ff3d3d;

            border: none;

            border-radius: 6px;

            color: white;

            font-weight: bold;

        }

    </style>

</head>

<body>

<div class="box">

    <h2>Admin Login</h2>

    <?php if (!empty($error)) echo "<p style='color:red;'>$error</p>"; ?>

    <form method="POST">

        <input type="password" name="password" placeholder="Nhập mật khẩu admin">

        <button type="submit">Đăng nhập</button>

    </form>

</div>

</body>

</html>