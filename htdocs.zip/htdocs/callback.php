<?php

// Kết nối DB

$conn = new mysqli("localhost", "username", "password", "dbname");

if ($conn->connect_error) die("Lỗi DB");

// Hàm tạo key

function generateKey() {

    $prefix = "CossThha";

    $part1 = substr(str_shuffle("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"), 0, 4);

    $part2 = substr(str_shuffle("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"), 0, 3);

    $part3 = substr(str_shuffle("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"), 0, 3);

    return "$prefix-$part1-$part2-$part3";

}

$key = generateKey();

$expires = time() + 86400; // 24h

// Lưu vào DB

$stmt = $conn->prepare("INSERT INTO keys (thekey, expires, used) VALUES (?, ?, 0)");

$stmt->bind_param("si", $key, $expires);

$stmt->execute();

$stmt->close();

$conn->close();

?>

<!DOCTYPE html>

<html>

<head>

<meta charset="utf-8">

<title>Your Key</title>

</head>

<body style="text-align:center;margin-top:100px;font-size:22px;">

    <h2>🎉 Get Key Thành Công!</h2>

    <p style="font-size:26px;color:green;font-weight:bold;"><?php echo $key; ?></p>

    <p>Key có hiệu lực trong 24 giờ.</p>

</body>

</html>