<?php

session_start();

$response = ["success" => false, "message" => ""];

// database

$host = "sql305.infinityfree.com";

$dbUsername = "if0_40606621";

$dbPassword = "0564551032";

$dbName = "if0_40606621_keysystem";

$conn = new mysqli($host, $dbUsername, $dbPassword, $dbName);

if ($conn->connect_error) {

    $response["message"] = "Lỗi kết nối database!";

} else {

    $conn->set_charset("utf8");

    if ($_SERVER["REQUEST_METHOD"] === "POST") {

        $username = trim($_POST["username"]);

        $password = trim($_POST["password"]);

        if (empty($username) || empty($password)) {

            $response["message"] = "Vui lòng nhập đầy đủ!";

        } else {

            $stmt = $conn->prepare("SELECT password FROM users WHERE username = ?");

            $stmt->bind_param("s", $username);

            $stmt->execute();

            $result = $stmt->get_result();

            if ($result->num_rows > 0) {

                $user = $result->fetch_assoc();

                if (password_verify($password, $user["password"])) {

                    $_SESSION["username"] = $username;

                    $response["success"] = true;

                    $response["message"] = "Đăng nhập thành công!";

                } else {

                    $response["message"] = "Sai mật khẩu!";

                }

            } else {

                $response["message"] = "Tên đăng nhập không tồn tại!";

            }

            $stmt->close();

        }

    }

}

?>

<!DOCTYPE html>

<html lang="vi">

<head>

    <meta charset="UTF-8">

    <title>Đăng Nhập</title>

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

<style>

    *{margin:0;padding:0;box-sizing:border-box;font-family:Arial,sans-serif;}

    body{

        background:#6C2BD9;

        background-image:linear-gradient(135deg,#6C2BD9 0%,#4A148C 100%);

        height:100vh;

        display:flex;

        justify-content:center;

        align-items:center;

    }

    .login-box{

        background:#fff;

        padding:35px 28px;

        border-radius:8px;

        width:90%;

        max-width:340px;

        text-align:center;

        box-shadow:0 4px 20px rgba(0,0,0,0.15);

    }

    .logo{

        width:80px;

        height:80px;

        margin:0 auto 20px;

        background:url('/assets/icon/png/logo.png') center/contain no-repeat;

    }

    h2{

        color:#2D2D2D;

        font-size:22px;

        margin-bottom:30px;

        font-weight:600;

    }

    .form-group{margin-bottom:22px;text-align:left;}

    .form-group label{

        color:#666;

        margin-bottom:6px;

        display:block;

        font-size:14px;

    }

    .form-group input{

        width:100%;

        padding:12px 15px;

        border:1px solid #E0E0E0;

        border-radius:4px;

        font-size:14px;

        transition:border-color .3s;

    }

    .form-group input:focus{

        border-color:#6C2BD9;

        outline:none;

    }

    .forgot-pass {

    text-align: right;

    margin-top: 10px;

    margin-bottom: 15px;

}

.forgot-pass a {

    color: #007BFF;

    font-size: 13px;

    text-decoration: none;

}

    .login-btn{

        width:100%;

        padding:13px;

        background:#007BFF;

        color:#fff;

        border:none;

        border-radius:4px;

        font-size:16px;

        cursor:pointer;

        margin:12px 0;

        transition:.3s;

    }

    .login-btn:hover{background:#0056B3;}

    .register-link{margin-top:18px;font-size:14px;color:#666;}

    .register-link a{color:#007BFF;text-decoration:none;}

    .alert{

        padding:10px;

        margin-bottom:15px;

        border-radius:4px;

        font-size:14px;

    }

    .alert-success{background:#D4EDDA;color:#155724;}

    .alert-error{background:#F8D7DA;color:#721C24;}

</style>

</head>

<body>

    <div class="login-box">

        <div class="logo"></div>

        <h2>Đăng Nhập</h2>

        <?php if ($_SERVER["REQUEST_METHOD"] === "POST"): ?>

            <div class="alert <?php echo $response["success"] ? "alert-success" : "alert-error"; ?>">

                <?php echo $response["message"]; ?>

            </div>

        <?php endif; ?>

        <form method="POST" action="">

            <div class="form-group">

                <label>Tên đăng nhập</label>

                <input type="text" name="username" placeholder="Nhập username" required>

            </div>

            <div class="form-group">

                <label>Mật khẩu</label>

                <input type="password" name="password" placeholder="Nhập mật khẩu" required>

                <div class="forgot-pass">

    <a href="forgot.php">Quên mật khẩu?</a>

</div>

            </div>

            <button type="submit" class="login-btn">Đăng Nhập</button>

        </form>

        <div class="register-link">

            Chưa có tài khoản? <a href="register.php">Đăng ký</a>

        </div>

    </div>

</body>

</html>