setTimeout(() => {

    let audio = document.getElementById("bgm");

    if (localStorage.getItem("music") === "off") {

        audio.pause();

        document.getElementById("musicBtn").textContent = "🔇";

    } else {

        audio.muted = false;

        audio.play().catch(()=>{});

        document.getElementById("musicBtn").textContent = "🎵";

        localStorage.setItem("music", "on");

    }

}, 700);

// NÚT NHẠC

document.getElementById("musicBtn").onclick = function () {

    let audio = document.getElementById("bgm");

    if (audio.paused) {

        audio.play();

        this.textContent = "🎵";

        localStorage.setItem("music", "on");

    } else {

        audio.pause();

        this.textContent = "🔇";

        localStorage.setItem("music", "off");

    }

};