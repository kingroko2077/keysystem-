<?php

// config.php

session_start();

$host = "sql305.infinityfree.com";

$db_user = "if0_40606621";

$db_pass = "0564551032";

$db_name = "if0_40606621_keysystem";

$conn = mysqli_connect($host, $db_user, $db_pass, $db_name);

mysqli_set_charset($conn, "utf8mb4");

if (!$conn) {

    // không show password

    die("Lỗi kết nối database.");

}

// helper: bảo vệ trang admin

function require_admin() {

    if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {

        header("Location: /login.php");

        exit;

    }

}